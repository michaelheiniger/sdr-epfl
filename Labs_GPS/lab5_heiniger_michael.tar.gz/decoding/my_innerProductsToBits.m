% INNERPRODUCTSTOBITS Make hard decisions about the transmitted bits
% DECODEDBITS = INNERPRODUCTSTOBITS(BITWISEINNERPRODUCTRESULTS)
% Returns in DECODEDBITS a vector of the same dimensions as 
% BITWISEINNERPRODUCTS with the hard decisions about the transmitted bits.
% The elements of DECODEDBITS are 1 or -1
